<div class="agileits_main">
<!-- header -->
<div class="w3_agile_logo">
	<!-- <h1 class="text-center"><a href="index.html">aji charapita</a></h1> -->
	<h1 class="text-center"><a href="index.html"> </a></h1>
</div>
<!-- banner -->
<?php echo $__env->make('components.banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- menu -->
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //menu -->
  </div>