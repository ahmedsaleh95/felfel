<div class="tooltip-content">
	<div class="modal fade features-modal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h2 class="modal-title text-center">Quinoa</h2>
				</div>
				<div class="modal-body">
					<img src="images/048.jpg" alt="image">
					<p>One of the most important crops in the world we will provide it so wait for us .</p>
				</div>
			</div>
		</div>
	</div>
</div>