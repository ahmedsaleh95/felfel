<div class="agileits_main">
<!-- header -->
<div class="w3_agile_logo">
	<!-- <h1 class="text-center"><a href="index.html">aji charapita</a></h1> -->
	<h1 class="text-center"><a href="index.html"> </a></h1>
</div>
<!-- banner -->
@include('components.banner')
<!-- menu -->
@include('components.nav')
<!-- //menu -->
  </div>