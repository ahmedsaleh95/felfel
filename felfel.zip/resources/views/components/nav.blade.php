<nav class="navbar navbar-inverse ">
	<div class="container">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
		</button>
	<div class="collapse navbar-collapse top-nav w3l" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav linkEffects linkHoverEffect_11 custom-menu">
			<li class="agile_active"><a href="index.html" class="scroll"><span>home</span></a></li>
			<li><a href="#about" class="scroll"><span>about us</span></a></li>
			<li><a href="#ajicharapita" class="scroll"><span>aji charapita </span></a></li>
			<li><a href="#amaranth" class="scroll"><span>amaranth </span></a></li>
			<li><a href="#quinoa" class="scroll"><span>quinoa </span></a></li>
			<!-- <li><a href="#gallery" class="scroll"><span>gallery </span></a></li> -->
			<!-- <li><a href="#team" class="scroll"><span>team</span></a></li> -->
			<li><a href="#contact" class="scroll"><span>Contact</span></a></li>
		</ul>
	</div>
	</div>
</nav>