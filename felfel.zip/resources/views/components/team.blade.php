<div class="team agileits-w3layouts" id="team">
	<div class="container">
		<h3 class="title">our Team</h3>  
		<div class="team-w3ls">
			<div class="col-md-4 col-sm-4 col-xs-4 team-grid w3_agileits">
				<img class="img-w3l t1-wthree img-responsive" src="images/t1.jpg" alt="">
				<h5>Mercurio</h5>
				<p>Lorem ipsum dolor sit amet.Cras rutrum iaculis enim, non convallis felis mattis.</p>
				<div class="social-icons">
					<ul>
						<li><a href="#" class="fa fa-facebook icon icon-border facebook"> </a></li>
						<li><a href="#" class="fa fa-twitter icon icon-border twitter"> </a></li>
						<li><a href="#" class="fa fa-google-plus icon icon-border googleplus"> </a></li>
					</ul>
					<div class="clearfix"> </div>
				</div> 
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 team-grid w3_agileits t2">
				<img class="img-w3l t1-wthree img-responsive" src="images/t2.jpg" alt="">
				<h5>Clifford</h5>
				<p>Lorem ipsum dolor sit amet.Cras rutrum iaculis enim, non convallis felis mattis.</p>
				<div class="social-icons">
					<ul>
						<li><a href="#" class="fa fa-facebook icon icon-border facebook"> </a></li>
						<li><a href="#" class="fa fa-twitter icon icon-border twitter"> </a></li>
						<li><a href="#" class="fa fa-google-plus icon icon-border googleplus"> </a></li>
					</ul>
					<div class="clearfix"> </div>
				</div> 
			</div>
			<div class="col-md-4 col-sm-4 col-xs-4 w3_agileits team-grid">
				<img class="img-w3l t1-wthree img-responsive" src="images/t3.jpg" alt="">
				<h5>Davidson</h5>
				<p>Lorem ipsum dolor sit amet.Cras rutrum iaculis enim, non convallis felis mattis.</p>
				<div class="social-icons agile">
					<ul>
						<li><a href="#" class="fa fa-facebook icon icon-border facebook"> </a></li>
						<li><a href="#" class="fa fa-twitter icon icon-border twitter"> </a></li>
						<li><a href="#" class="fa fa-google-plus icon icon-border googleplus"> </a></li>
					</ul>
					<div class="clearfix"> </div>
				</div> 
			</div>
			<div class="clearfix"> </div>
		</div>   
	</div>
</div>