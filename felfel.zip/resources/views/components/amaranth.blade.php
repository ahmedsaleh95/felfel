<!-- style="background: #a11640;" -->
<div class="gallery_wthree" id="amaranth">
 <div class="container">
      <h3 class="title">amaranth</h3>
	  <div class="gallery_grid agileits_w3layouts">
	    <div class="col-md-6  col-sm-6 col-xs-6 grid_w3">
			<div class="grid-1">
				<a class="cm-overlay" href="images/amaranth/IMG_3894.jpg">
					<img src="images/amaranth/IMG_3894.jpg" alt=" " class="img-responsive" />
					 <div class="w3agile-text w3agile-text-smal1">
						<h5>Snap shot</h5>
					</div>
				</a>
			</div>
			 <div class="sub_grid gallery_w3l">
				   <div class="col-md-6 col-sm-6 col-xs-6 grid-1 grid-c grid_w3l">
						<a class="cm-overlay" href="images/amaranth/IMG_4078.jpg">
							<img src="images/amaranth/IMG_4078.jpg" alt=" " class="img-responsive" />
							<div class="w3agile-text w3agile-text-small">
								<h5>Snap shot</h5>
					        </div>
						</a>
					</div>
				   <div class="col-md-6 col-sm-6 col-xs-6 grid-1 grid-b grid_w3l">
					 	<a class="cm-overlay" href="images/amaranth/IMG_4097.jpg">
							<img src="images/amaranth/IMG_4097.jpg" alt=" " class="img-responsive" />
							<div class="w3agile-text w3agile-text-smal1">
								<h5>Snap shot</h5>
							</div>
						</a>
					</div>
				   <div class="clearfix"></div>
			 </div>  
        </div>
		<div class="col-md-6 col-sm-6 col-xs-6 grid_w3">
		   <div class="sub_grid">
			   <div class="col-md-6 col-sm-6 col-xs-6 grid-1 grid-c grid_w3l">
          			<a class="cm-overlay" href="images/amaranth/IMG_4015.jpg">
						<img src="images/amaranth/IMG_4015.jpg" alt=" " class="img-responsive" />
						<div class="w3agile-text w3agile-text-small">
							<h5>Snap shot</h5>
						</div>
					</a>
			   </div>
			   <div class="col-md-6 col-sm-6 col-xs-6 grid-1 grid-d grid_w3l">
					<a class="cm-overlay" href="images/amaranth/IMG_4033.jpg">
						<img src="images/amaranth/IMG_4033.jpg" alt=" " class="img-responsive" />
						<div class="w3agile-text w3agile-text-smal1">
							<h5>Snap shot</h5>
						</div>
					</a>
				</div>
				 <div class="clearfix"></div>
			   </div>
		    <div class="grid-1 grid-2">
				<a class="cm-overlay" href="images/amaranth/IMG_4000.jpg">
					<img src="images/amaranth/IMG_4000.jpg" alt=" " class="img-responsive" />
					<div class="w3agile-text w3agile-text-smal1">
							<h5>Snap shot</h5>
					</div>
				</a>
		    </div>
		   <div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	  </div>	
</div>
</div>