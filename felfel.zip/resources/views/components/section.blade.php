<div class="w3layouts-section" id="quinoa">
	<div class="container">   
		<h3 class="title">What`s new?!</h3> 
		<p>We provide Latin crops like Armanth and Aj charapita , we know that you wonder what`s our next products in farming field gues whats</p>
		<a href="#myModal" class="agilebtn" data-toggle="modal" data-target="#myModal"><span>See Coming Product</span></a>
	</div>
</div>