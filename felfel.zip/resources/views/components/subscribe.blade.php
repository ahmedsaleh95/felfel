<div class="subscribe w3_agile">
 <div class="container">
    <h3 class="title text-center">subscribe</h3>
	<div class="subscribe-wthree">
		<form action="#" method="post">
			<input type="email" placeholder="Enter email" required=""> 
			<input type="submit" value="subscribe" class="botton">
		</form> 
	</div>
 </div>	
</div>