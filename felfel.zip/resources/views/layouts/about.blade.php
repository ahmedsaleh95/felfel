<div class="about_agileinfo" id="about">
  <div class="container">
      <h3 class="title">about us</h3>
	  <div class="about_main">
		  <!-- <div class="col-md-6 col-sm-6 col-xs-6 about_agileits"></div> -->
		  <div class="col-md-6 col-sm-6 col-xs-6 col-md-offset-3 col-sm-offset-3 col-lg-offset-3 about_text_w3l">
		    <!-- <h4>Lorem Ipsum</h4> -->
			<P>we are an Egyptian company that is passionate about agricultural Reasearch & Development specially on corps that did not exist locally to bring an added value to the market and act as a new hub for the European nations that needs latin corps on constant basis with premium quality.
				
			</P>
		  </div>
		  <div class="clearfix"></div>
	  </div>	  
  </div>
 </div> 