<div class="agileits_main">
<!-- header -->

@include('layouts.nav')


@include('layouts.header')

<!-- banner -->
@include('layouts.banner')
<!-- menu -->

<!-- //menu -->
  </div>