<div class="home_ w3layouts">
 <div class="home_grids_w3">
  <div class="home_main">
	   <div class="col-md-7 col-sm-7 col-xs-7 img1 img-grid">
		   <div class="img_text_w3ls text-center">
				<h4> </h4>
				<span> </span>
				<p> </p>
			</div>
		</div>
		<div class="col-md-5 img2 col-sm-5 col-xs-5 img-grid">
		    <div class="img_text_w3ls text-center">
				<h4>red aji charapita.</h4>
				<span> </span>
				<p> </p>
			  </div>
		</div>
		<div class="clearfix"></div>
	</div>
  <div class="home_main">
	   <div class="col-md-5 col-sm-5 col-xs-5 img3 img-grid ">
		    <div class="img_text_w3ls text-center">
				<h4>our own farms.</h4>
				<span> </span>
				<p> </p>
			  </div>
		</div>
	  <div class="col-md-7 col-sm-7 col-xs-7 img4 img-grid">
		    <div class="img_text_w3ls text-center">
				<h4>mix pepper.</h4>
				<span> </span>
				<p> </p>
			</div>
	 </div>
	<div class="clearfix"></div>
  </div>
   <div class="home_main">
	   <div class="col-md-7 col-sm-7 col-xs-7 img-grid  img5">
		  <div class="img_text_w3ls text-center">
				<h4></h4>
				<span> </span>
				<p></p>

		  </div>
		 </div>
		<div class="col-md-5 col-sm-5 col-xs-5 img-grid img6">
		  <div class="img_text_w3ls text-center">
				<h4>.</h4>
				<span> </span>
				<p></p>
		  </div>
		 </div>
		<div class="clearfix"></div>
  </div>
</div>
</div>