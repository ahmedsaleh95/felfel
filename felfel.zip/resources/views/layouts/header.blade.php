<div class="w3_agile_logo">
	<h1 class="text-center"><a href="index.html">aji charapita</a></h1>
</div>