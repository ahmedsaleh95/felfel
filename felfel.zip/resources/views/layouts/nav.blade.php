<nav class="navbar navbar-inverse ">
	<div class="container">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
		</button>
	<div class="collapse navbar-collapse top-nav w3l" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav linkEffects linkHoverEffect_11 custom-menu">
			<li class="agile_active"><a href="index.html" class="scroll"><span>home</span></a></li>
			<li><a href="#about" class="scroll"><span>about us</span></a></li>


			<li><a href="#felfel" class="scroll Li_hidden"><span>aji charapita</span></a></li>
			<li><a href="#bnfsgy" class="scroll Li_hidden"><span>amaranth</span></a></li>
			<li><a href="#bnfsgy" class="scroll Li_hidden"><span>quinoa</span></a></li>


			<li><a href="#gallery" class="scroll"><span>gallery </span></a></li>
			<!-- <li><a href="#team" class="scroll"><span>team</span></a></li>				 -->
			<!-- <li class="product"><a href="#" class="scroll "><span>product</span></a></li> -->


         <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>

		  <script>
			// You can also use "$(window).load(function() {"
			$(function () {

				$(".product").hover(function() {
					/* Stuff to do when the mouse enters the element */
					// x = $(this).position();
			  // 		$(".Li_hidden").removeClass('hidden');
			  		// $(".Li_hidden").css({top: $(this).position().top + 70 , left: $(this).position().left-830});

				}, function() {
					/* Stuff to do when the mouse leaves the element */
			  	// $(".Li_hidden").addClass('hidden');
				});
			});
		 </script>
	</div>
	</div>
</nav>